package pilha;

/**
 *
 * @author Mateus
 */
public class No {

    private Object valor;
    private No anterior;

    public No(Object valor, No anterior) {
        this.valor = valor;
        this.anterior = anterior;
    }

    public Object getValor() {
        return valor;
    }

    public void setValor(Object valor) {
        this.valor = valor;
    }

    public No getAnterior() {
        return anterior;
    }

    public void setAnterior(No anterior) {
        this.anterior = anterior;
    }

}
