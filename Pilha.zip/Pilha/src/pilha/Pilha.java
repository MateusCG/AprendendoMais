package pilha;

/**
 *
 * @author Mateus Codigo em Pilha Dinâmica
 */
public class Pilha {

    private No topo;
    public int qtd = 0;

    public void inserir(Object a) {
        No noAtual = new No(a, topo);
        topo = noAtual;
        qtd++;
    }

    public Object remover() {
        if (!pilhaVazia()) {
            Object temp = topo.getValor();
            this.topo = topo.getAnterior();
            qtd--;
            return temp;
        } else {
            return "Pilha vazia";
        }
    }

    public boolean pilhaVazia() {
        if (qtd == 0) {
            //System.out.println("pilha vazia");
            return true;
        }
        //System.out.println("pilha cheia");
        return false;
    }

    public Object topoPilha() {
        return topo.getValor();
    }

    public void mostrar() {
        if (pilhaVazia()) {
            System.out.println("Pilha Vazia");
        }
        No aux = topo;
        while (aux != null) {
            System.out.println(aux.getValor() + " ");;
            aux = aux.getAnterior();
        }
    }

    public static void main(String[] args) {
        Pilha p = new Pilha();

        p.inserir("Mauricio");
        p.inserir(99);
        p.inserir("mariana");
        p.inserir("Marcos");
        p.inserir("cenoura");
        p.inserir("tatiane");
        p.mostrar();
        p.remover();
        System.out.println("=====================");
        p.mostrar();

        while (!p.pilhaVazia()) {
            p.remover();
        }

        System.out.println("=================");
        p.mostrar();
    }

}
